from pathlib import Path
import hashlib,json,sys,zipfile
WORK=Path(__file__).resolve().parent
REPO=WORK/'Vic3-optimazation'
OUT=REPO/'research/generated/pc-evidence-2026-10-05'
sys.path.insert(0,str(REPO/'tools'))
from analyze_vic3 import PE

def dump(name,obj):(OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
bins=[]
for source in ['D:/SteamLibrary/steamapps/common/Victoria 3/binaries','E:/Victoria 3/binaries']:
    for p in sorted(Path(source).glob('*')):
        if p.suffix.lower() not in {'.exe','.dll'}:continue
        b=p.read_bytes();row={'source':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
        try:
            pe=PE(b);row.update(image_base=hex(pe.imagebase),entry_point_rva=hex(pe.entry),sections=pe.sections,imports=pe.imports(),exports=pe.exports())
        except Exception as e:row['pe_metadata_error']=str(e)
        bins.append(row)
dump('binary-dependency-index.json',bins)
with zipfile.ZipFile(OUT/'collection-methods.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in ['collect_evidence.py','analyze_collected.py','finalize_evidence.py']:z.write(WORK/name,name)
    z.writestr('README.txt','One-off collection provenance scripts, not a supported product API. Run from a fresh work folder containing a checkout named Vic3-optimazation. Source paths are fixed to the authorized PC. Outputs are regenerated under the checkout and may overwrite same-date results. No source/game writes. Do not run against this preserved evidence checkout without first making a separate working copy. analyze_collected.py imports existing repository analysis tools.\n')
# Preserve all 68 test results, including optional Capstone and live fixture integration.
(OUT/'repository-test-results.txt').write_bytes((WORK/'repository-test-results.txt').read_bytes())

scope=json.loads((OUT/'scope.json').read_text(encoding='utf8'))
parts=json.loads((OUT/'save-parts.json').read_text(encoding='utf8'))
allfiles=[]
for folder in [OUT,REPO/'input-data/pc-evidence-2026-10-05']:
    for p in sorted(folder.rglob('*')):
        if not p.is_file() or p.name in {'preservation-index.json','benchmark-save.v3.gz'}:continue
        b=p.read_bytes();allfiles.append({'path':p.relative_to(REPO).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
dump('preservation-index.json',{'files':allfiles,'file_count':len(allfiles),'bytes':sum(x['bytes'] for x in allfiles),'full_gzip_not_uploaded':'The complete gzip remains local; the ordered parts reproduce it exactly.','original_game_binaries_uploaded':False})
print('FINALIZED',len(allfiles),sum(x['bytes'] for x in allfiles),len(bins),flush=True)
