"""Additional one-off evidence analysis; source data is read only."""
from pathlib import Path
from collections import Counter
import csv,gzip,hashlib,json,re,statistics,sys,zipfile
BASE=Path(__file__).resolve().parent/'Vic3-optimazation'
OUT=BASE/'research/generated/pc-evidence-2026-10-05'
RAW=BASE/'input-data/pc-evidence-2026-10-05'
sys.path.insert(0,str(BASE/'tools'))
from analyze_benchmarks import load_csv

def dump(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()

# Verify save restoration byte-for-byte and link duplicates by actual content hash.
saves=json.loads((OUT/'save-index.json').read_text(encoding='utf8'))
h=hashlib.sha256();size=0
with gzip.open(RAW/'benchmark-save.v3.gz','rb') as f:
    for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b);size+=len(b)
assert h.hexdigest()==saves[0]['sha256'] and size==saves[0]['bytes']
duplicates=[s['source'] for s in saves[1:] if s['sha256']==saves[0]['sha256']]
header=(OUT/'benchmark-save-header.txt').read_text(encoding='utf8')
keys=['save_game_version','version','game_date','real_date','name','rank','achievement_eligibility','number_of_players','date','seed','speed']
meta={k:re.search(r'^\s*'+k+r'=(.*)$',header,re.M).group(1).strip() for k in keys if re.search(r'^\s*'+k+r'=(.*)$',header,re.M)}
meta['date']=re.search(r'^date=(.*)$',header,re.M).group(1).strip()
meta['pop_consolidation']='aggressive_consolidation' if 'aggressive_consolidation' in header else None
dump('save-validation.json',{'restored_bytes':size,'restored_sha256':h.hexdigest(),'gzip_sha256':sha(RAW/'benchmark-save.v3.gz'),'exact_duplicate_paths':duplicates,'header_fields':meta,'claim_limit':'Recovered save matches metadata of previous benchmark. No previously recorded exact save SHA was available to prove identity with all historical runs.'})
print('save restored',size,len(duplicates),flush=True)

# Preserve original small attachments and record contents/hashes of larger containers.
extra=[]
for p in [Path('E:/benchmark_result.zip'),Path('E:/bench2.zip'),Path('E:/bench3.zip'),Path('E:/logs2.zip'),Path('E:/vic3_logs.zip'),Path('D:/vic3_gui.zip'),Path('D:/downloads/Victoria 3 Performance-32-1-00-0-1745087611.zip')]:
    if not p.exists():continue
    row={'source':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
    with zipfile.ZipFile(p) as z:
        row['members']=[{'path':i.filename,'bytes':i.file_size,'compressed_bytes':i.compress_size,'crc32':f'{i.CRC:08x}'} for i in z.infolist()]
    if p.stat().st_size<2*1024*1024:
        dest=RAW/('original-'+p.name)
        dest.write_bytes(p.read_bytes()); row['stored_path']=dest.relative_to(BASE).as_posix()
    else:row['stored_path']=None
    extra.append(row)
dump('original-archive-index.json',extra)

# Keep the original records separate; old CSV captures have no trustworthy wall-clock boundary.
series=[]
for source in ['E:/benchmark_result','E:/bench2','E:/bench3']:
    for p in sorted(Path(source).glob('*')):
        if not p.name.lower().startswith('ticktask_timings') or p.suffix.lower()!='.csv':continue
        rows=list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
        tasks=load_csv(p)
        series.append({'source':str(p),'sha256':sha(p),'rows':len(rows),'frames':len({r['frame'] for r in rows}),'tasks':len(tasks),'sum_recorded_task_ms':sum(t['total_ms'] for t in tasks.values()),'wall_clock_seconds':None,'top_cost':sorted([dict(task=n,**v) for n,v in tasks.items()],key=lambda t:-t['total_ms'])[:20],'top_lock':sorted([dict(task=n,**v) for n,v in tasks.items()],key=lambda t:-t['longest_lock_ms'])[:20]})
dump('historical-ticktask-comparison.json',{'series':series,'warning':'Stored task durations can overlap and are not simulation elapsed time. These are separate captures, not repeats or causal A/B measurements.'})

# Retain duplicate HWiNFO header columns by position; never let DictReader overwrite them.
captures=[]
for folder in ['E:/benchmark_result','E:/bench2']:
    for p in sorted(Path(folder).glob('*.CSV')):
        raw=p.read_bytes(); text=raw.decode('utf-8-sig',errors='surrogateescape');rows=list(csv.reader(text.splitlines()))
        cp932_cells=0; undecodable_cells=0
        for row in rows:
            for i,cell in enumerate(row):
                if any(0xdc80<=ord(c)<=0xdcff for c in cell):
                    try: row[i]=cell.encode('utf8','surrogateescape').decode('cp932');cp932_cells+=1
                    except UnicodeError: row[i]=cell.encode('utf8','surrogateescape').decode('utf8','replace');undecodable_cells+=1
        if len(rows)<2 or rows[0][:2]!=['Date','Time']:continue
        header=rows[0];data=[r for r in rows[1:] if len(r)>2 and re.fullmatch(r'\d+\.\d+\.\d+',r[0])]
        numeric=[];flags=[]
        for i,col in enumerate(header):
            vals=[]
            for row in data:
                try:v=float(row[i])
                except (ValueError,IndexError):continue
                vals.append(v)
            if vals and any(k.lower() in col.lower() for k in ['CPU','実効クロック','アクティブ コア','DRAM','物理メモリ','PPT','Thermal','スロットリング','温度','電力']):
                numeric.append({'column_index':i,'label':col,'samples':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals)})
            if 'Yes/No' in col and any(k in col for k in ['スロットリング','PMIC']):
                flags.append({'column_index':i,'label':col,'observed_values':dict(Counter(r[i] for r in data if i<len(r)))})
        captures.append({'source':str(p),'sha256':sha(p),'samples':len(data),'column_count':len(header),'duplicate_column_names':{k:v for k,v in Counter(header).items() if v>1},'first_timestamp':data[0][:2] if data else None,'last_timestamp':data[-1][:2] if data else None,'cp932_fallback_cells':cp932_cells,'undecodable_cells':undecodable_cells,'numeric_metrics':numeric,'flags':flags})
dump('sensor-capture-summary.json',{'captures':captures,'warning':'Whole capture statistics include idle/loading/simulation unless a benchmark interval is supplied. Duplicate headers are preserved by index. Mixed UTF8 headers and CP932 status values are decoded per cell; original raw bytes remain archived. Known negative flags do not rule out unrecorded events or prove benchmark synchronization.'})

# Compare script sources between same-sized current/historical installations.
archived=json.loads((OUT/'source-files.json').read_text(encoding='utf8'))
controls=[]
for e in archived:
    if e['root']!='historical-controls':continue
    p=Path('D:/SteamLibrary/steamapps/common/Victoria 3')/e['path']
    controls.append({'path':e['path'],'historical_sha256':e['sha256'],'installed_sha256':sha(p) if p.exists() else None,'equal':p.exists() and sha(p)==e['sha256']})
dump('historical-current-controls-comparison.json',{'files':controls,'compared':len(controls),'different':sum(not x['equal'] for x in controls)})

# Script-backed diagnostic fixture catalogue, preserving actual source and distinguishing examples.
fixtures=[]
for a in json.loads((OUT/'archive-index.json').read_text(encoding='utf8')):
    with zipfile.ZipFile(BASE/a['path']) as z:
        for name in z.namelist():
            if any(k in name.lower() for k in ['scripted_test','profiler','profiling','performance','thread']):
                fixtures.append({'archive':a['path'],'path':name,'bytes':z.getinfo(name).file_size})
dump('diagnostic-source-catalog.json',{'fixtures':fixtures,'claim_limit':'Shipped examples and profiler controls, not proof that a particular retail-build invocation works.'})
dump('additional-analysis-validation.json',{'saved_capture_count':len(series),'sensor_capture_count':len(captures),'save_restoration_verified':True,'historical_controls_compared':len(controls),'source_write_operations':0})
print('COMPLETE additional',len(series),len(captures),len(controls),len(fixtures),flush=True)
