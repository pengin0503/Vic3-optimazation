"""One-off read-only Victoria 3 evidence collection. Outputs stay in this workspace."""
from pathlib import Path
import csv, gzip, hashlib, json, os, re, sqlite3, sys, time, zipfile
from collections import Counter

ROOT = Path(__file__).resolve().parent / 'Vic3-optimazation'
OUT = ROOT / 'research/generated/pc-evidence-2026-10-05'
RAW = ROOT / 'input-data/pc-evidence-2026-10-05'
OUT.mkdir(parents=True, exist_ok=True)
RAW.mkdir(parents=True, exist_ok=True)
LIVE = Path('D:/SteamLibrary/steamapps/common/Victoria 3')
USER = Path('C:/Users/pengin0053/Documents/Paradox Interactive/Victoria 3')
TEXT = {'.txt','.gui','.json','.yml','.yaml','.csv','.tsv','.settings','.lua','.py','.h','.hpp','.cpp','.c','.shader','.fx','.fxh','.info','.mod','.md','.log','.asset','.xml','.vdf','.acf','.bat','.ps1','.ahk'}
errors, changed, inventory, archived, archives = [], [], [], [], []
started = time.strftime('%Y-%m-%dT%H:%M:%S%z')

def write_json(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()

def files(root):
    def onerror(e): errors.append({'path':str(e.filename),'error':str(e)})
    if not root.exists(): return []
    return sorted((Path(d)/n for d,dirs,names in os.walk(root,onerror=onerror) for n in names), key=lambda p:p.as_posix().lower())

roots = {'installed-game':LIVE, 'historical-game':Path('E:/Victoria 3'),
         'workshop':Path('D:/SteamLibrary/steamapps/workshop/content/529340'),
         'workshop-k':Path('K:/SteamLibrary/steamapps/workshop/content/529340'),
         'user-data':USER, 'bench1':Path('E:/benchmark_result'), 'bench2':Path('E:/bench2'),
         'bench3':Path('E:/bench3'), 'logs2':Path('E:/logs2'),
         'recovery-gui':Path('D:/vic3_gui'),
         'old-batch-mod':Path('D:/Vic3-Priority-Batch-Construction-0.1.1')}
found={}
for label, folder in roots.items():
    ff=files(folder); found[label]=ff
    total=0
    for p in ff:
        try:
            st=p.stat(); total+=st.st_size
            inventory.append({'root':label,'path':p.relative_to(folder).as_posix(),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns})
        except OSError as e: errors.append({'path':str(p),'error':str(e)})
    print('inventory',label,len(ff),total,flush=True)

def archive(label, folder, selected):
    if not selected: return
    target=RAW/(label+'.zip')
    items=[]
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in selected:
            try:
                before=p.stat(); b=p.read_bytes(); after=p.stat()
                if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
                    changed.append(str(p)); continue
                logical=p.relative_to(folder).as_posix()
                info=zipfile.ZipInfo(logical, (1980,1,1,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
                z.writestr(info,b,compresslevel=9)
                row={'root':label,'path':logical,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':target.relative_to(ROOT).as_posix(),'member':logical}
                archived.append(row); items.append(row)
            except OSError as e: errors.append({'path':str(p),'error':str(e)})
    archives.append({'path':target.relative_to(ROOT).as_posix(),'bytes':target.stat().st_size,'sha256':digest(target),'members':len(items),'uncompressed_bytes':sum(x['bytes'] for x in items)})
    print('archive',label,len(items),target.stat().st_size,flush=True)

# All script/UI/control text in game subsystems; assets remain represented in inventory.
for group in ('game/common','game/events','game/gui','game/data_binding','game/input_profile','game/interface','game/notifications','game/tools','game/dlc_metadata','jomini','clausewitz','platform_specific_game_data'):
    selected=[p for p in found['installed-game'] if p.relative_to(LIVE).as_posix().startswith(group+'/') and p.suffix.lower() in TEXT]
    archive('installed-'+group.replace('/','-'),LIVE,selected)
archive('installed-root-controls',LIVE,[p for p in found['installed-game'] if p.parent==LIVE or (p.parent==LIVE/'game' and p.suffix.lower() in TEXT)])
# Retain historical controls and GUI for build drift comparison, not duplicate asset payloads.
historic=roots['historical-game']
archive('historical-controls',historic,[p for p in found['historical-game'] if p.suffix.lower() in TEXT and any(x in p.relative_to(historic).as_posix() for x in ('common/defines/','common/game_rules/','/gui/','/scripted_tests/'))])
for label in ('bench1','bench2','bench3','logs2','recovery-gui','old-batch-mod'):
    archive(label,roots[label],[p for p in found[label] if p.suffix.lower() in TEXT])
# Workshop scripts/configuration are useful even when disabled; no claim they affect current play.
archive('workshop-script-controls',roots['workshop'],[p for p in found['workshop'] if p.suffix.lower() in TEXT and p.stat().st_size<8*1024*1024 and any(x in '/'+p.relative_to(roots['workshop']).as_posix() for x in ('/common/','/events/','/gui/','/data_binding/','.metadata/','descriptor.mod'))])
selected=[p for p in found['user-data'] if p.suffix.lower() in TEXT and p.stat().st_size<16*1024*1024 and (p.parent==USER or p.relative_to(USER).parts[0] in {'logs','mod','crashes','exceptions','user_bindings','playsets_backup'})]
archive('current-user-data',USER,selected)

with gzip.open(OUT/'file-inventory.csv.gz','wt',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['root','path','bytes','mtime_ns']);w.writeheader();w.writerows(inventory)
write_json('source-files.json',archived)
write_json('archive-index.json',archives)
write_json('scope.json',{'started':started,'roots':{k:str(v) for k,v in roots.items()},'root_counts':{k:len(v) for k,v in found.items()},'inventory_files':len(inventory),'inventory_bytes':sum(x['bytes'] for x in inventory),'archived_members':len(archived),'text_selection_extensions':sorted(TEXT),'errors':errors,'unstable_reads_excluded':changed,'coverage':'Enumerated files in discovered Victoria 3 roots. Not an exhaustive search of every PC folder. Binary/media assets are inventory-only. No source writes, hooks, game launches or setting changes.'})

# Capture save metadata and reproducible compressed save without changing the original.
saves=[]
for p in found['bench2']+[p for p in found['user-data'] if p.suffix.lower()=='.v3' and 'save games' in p.parts]:
    if p.suffix.lower()!='.v3':continue
    st=p.stat(); target=RAW/'benchmark-save.v3.gz'
    if not saves:
        with p.open('rb') as src, target.open('wb') as dst, gzip.GzipFile(filename='',mode='wb',fileobj=dst,mtime=0,compresslevel=9) as gz:
            for b in iter(lambda:src.read(4*1024*1024),b''):gz.write(b)
        with p.open('rb') as f: header=f.read(100000).decode('utf-8','replace')
        (OUT/'benchmark-save-header.txt').write_text(header,encoding='utf-8')
    saves.append({'source':str(p),'bytes':st.st_size,'sha256':digest(p),'mtime_ns':st.st_mtime_ns,'compressed_archive':target.relative_to(ROOT).as_posix() if len(saves)==0 else None,'note':'Benchmark input recovered from E:/bench2; identity with previously measured save must be confirmed by saved hash and metadata, not filename alone.'})
write_json('save-index.json',saves)
print('saves',len(saves),flush=True)

# Catalog logs without treating old/rotated sessions as one benchmark.
logs=[]
for label in ('user-data','logs2'):
    for p in found[label]:
        if p.suffix.lower()!='.log':continue
        text=p.read_text(encoding='utf-8',errors='replace')
        patterns={k:len(re.findall(v,text,re.I)) for k,v in {'missing_dlc':'MISSING_DLC_ENTRY','invalid_gui_type':'not a valid type','kates_reference':'kates_','ticktask':'TickTask','task_thread_setting':'TaskThreadCount','assert_or_exception':'assert|exception|crash'}.items()}
        logs.append({'root':label,'path':p.relative_to(roots[label]).as_posix(),'lines':len(text.splitlines()),'bytes':p.stat().st_size,'pattern_counts':patterns,'sha256':digest(p)})
write_json('log-index.json',logs)

# Read launcher metadata via read-only SQLite; omit account-related tables.
db=USER/'launcher-v2.sqlite'; dbout={}
if db.exists():
    try:
        con=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
        names=[x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for name in names:
            if re.fullmatch(r'[A-Za-z0-9_]+',name) and ('mod' in name.lower() or 'playset' in name.lower()):
                cur=con.execute('SELECT * FROM "'+name+'"'); cols=[x[0] for x in cur.description]
                safe=[i for i,c in enumerate(cols) if not re.search('token|password|email|account|auth|userId|owner',c,re.I)]
                dbout[name]=[{cols[i]:r[i] for i in safe} for r in cur.fetchall()]
        con.close()
    except Exception as e:dbout={'error':str(e)}
write_json('launcher-mod-playsets.json',dbout)

# Re-check archive contents against per-source hashes; corruption is a hard failure.
for a in archives:
    with zipfile.ZipFile(ROOT/a['path']) as z:
        assert z.testzip() is None
        for e in [x for x in archived if x['archive']==a['path']]:
            assert hashlib.sha256(z.read(e['member'])).hexdigest()==e['sha256']
write_json('collection-validation.json',{'archives_validated':len(archives),'members_validated':len(archived),'source_changes_detected':changed,'source_write_operations':0,'read_errors':errors,'finished':time.strftime('%Y-%m-%dT%H:%M:%S%z')})
print('COMPLETE',len(archives),len(archived),len(inventory),flush=True)
