character_role_example = {
	type = politician 		# Archetype for this role, valid archetypes are politician/general/admiral/executive/agitator/ruler/heir/magnate. Roles do not need to have archetypes if they are fully controlled by script.
	priority = 1			# Used to select the primary title for a character, higher priority gets selected over lower

	auto_assigned = yes/no		# If this is set to yes, then all characters of this role's archetype will receive this role when created
	
	career_length = { min max }			# For how many years will a character hold this role before retiring (randomly set between min and max)
	
	# Root = character
	on_career_end = {}					# Effect that fires when a character retires from this role
		
	should_use_title_in_name = yes/no 	# If set to yes, characters with this role as primary will have its title in their titled name ('General Cupcakes Muffin III')
	title_format = from_name 			# Determines how titles are formatted, from_name/ruler/heir/custom, defaults to from_name. If set to custom, a customizable localization with the format key_custom_loc (example: character_role_politician_custom_loc) must be added to the customizable loc database.
	title_preposition = "PREP_IN"		# Determines the preposition when title is shown in country context (ie, 'Ruler in France'), uses define (english default: 'in') if not set
	
	spawn_characters_to_pool = yes/no 	# If set to yes, characters with this role will be spawned into the pool from templates and potentially also randomly depending on spawn target values below
	
	# The below values are used to control when new characters of a role should be randomly generated into the character pool
	# The target value is the number of characters of a specific role and IG we want to hang around in the pool at different levels of IG influence
	# Current IG leader is counted, as are other characters that are potentially valid for IG leadership
	# If the number of characters of this role hanging around in the pool is below the target, we will try to create a new character. 
	# Politicians generated randomly will get an ideology currently unrepresented in their IG, other characters use normal ideology selection
	# Characters generated from templates count towards but are not prevented from spawning by these values
	# Each of these is a script value, root = interest group
	# WARNING: Using complex script values here is likely to degrade performance!
	pool_spawn_target_powerful = 3		# Target if the character's IG is powerful
	pool_spawn_target_influential = 2	# Target if the character's IG is influential
	pool_spawn_target_marginal = 0		# Target if the character's IG is marginal
	
	# Alternative spawn control number, incompatible with IG spawn values above
	# Script value, target for number of characters from this role that should be spawned into the pool across a country. Created characters will be assigned IGs based via the normal IG selection logic from role etc.
	# Root = country
	pool_spawn_target_country_wide = {
		value = 0
	}
	
	# Applied to characters holding this role
	character_modifier = {
		character_prominence_add = 10
	}
}