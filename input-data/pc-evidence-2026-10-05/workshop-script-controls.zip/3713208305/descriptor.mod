﻿name="Voice's Enhanced Topbar [1.13]"
version="1.1.0"
supported_version="1.13.*"
tags={
	"Utilities"
	"Graphics"
}
