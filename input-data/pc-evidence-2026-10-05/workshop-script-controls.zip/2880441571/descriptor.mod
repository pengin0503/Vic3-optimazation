version="1.7"
tags={
	"Gameplay"
}
name="主角光环"
supported_version="1.*.*"