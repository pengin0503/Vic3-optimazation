﻿    key = {			# Current DNA data key
        dna = ""	# DNA String
        portrait_info = {	# Portrait-based way of specifying the DNA
            genes = {
                hair_color={ 14 244 25 255 }
                ...
                gene_cheek_puffy={ cheek_puffy_neg 109 cheek_puffy_neg 92 }
                ...
            }
        }
    }