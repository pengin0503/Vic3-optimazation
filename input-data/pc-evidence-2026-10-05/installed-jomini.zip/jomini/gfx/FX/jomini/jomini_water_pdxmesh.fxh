Includes = {
	"cw/pdxmesh.fxh"
	"jomini/jomini_water.fxh"
}
VertexShader =
{
	Code
	[[
		VS_OUTPUT_WATER ConvertOutputWater( VS_OUTPUT_PDXMESH MeshOutput, uint InstanceIndex )
		{
			VS_OUTPUT_WATER Output;

			Output.Position = MeshOutput.Position;
			Output.WorldSpacePos = MeshOutput.WorldSpacePos;
			Output.UV01 = float2( MeshOutput.WorldSpacePos.x / MapSize.x, 1.0 - MeshOutput.WorldSpacePos.z / MapSize.y );
			Output.InstanceIndex = InstanceIndex;

			return Output;
		}
	]]
	MainCode VS_jomini_water_mesh
	{
		Input = "VS_INPUT_PDXMESHSTANDARD"
		Output = "VS_OUTPUT_WATER"
		Code
		[[
			PDX_MAIN
			{
				return ConvertOutputWater( PdxMeshVertexShaderStandard( Input ), Input.InstanceIndices.y );
			}
		]]
	}
	MainCode VS_jomini_water_mapobject
	{
		Input = "VS_INPUT_PDXMESH_MAPOBJECT"
		Output = "VS_OUTPUT_WATER"
		Code
		[[
			PDX_MAIN
			{
				return ConvertOutputWater( PdxMeshVertexShader( PdxMeshConvertInput( Input ), 0, UnpackAndGetMapObjectWorldMatrix( Input.Index24_Packed1_Opacity6_Sign1 ) ), Input.Index24_Packed1_Opacity6_Sign1 );
			}
		]]
	}
}