name="Victoria 3 Performance Mod"
path="mod/vic3_performance"
tags={
    "Gameplay"
    "Optimization"
}
supported_version="1.9.*"
remote_file_id=""
version="1.0"