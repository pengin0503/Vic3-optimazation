// Neutralized lava shader
// Disabled all output


Suggested Fixes:
This mod appears to be for Victoria 3, not Crusader Kings 3. However, I can provide fixes based on the file structure and content, assuming the intention was to create a functional Victoria 3 mod focused on performance improvements.

**I. Syntax Errors in Event Files (and other script files):**

CK3 uses a specific syntax for events and other script files. Incorrect syntax can prevent the game from loading the files or cause unexpected behavior. While the example provided is for Victoria 3, here's how to address typical syntax issues, relevant to similar code structures that exist in CK3 events.

1.  **File Encoding:** Ensure all `.txt` files are encoded in UTF-8 with BOM.  This is crucial for special characters and proper parsing. Use a text editor like Notepad++ or VS Code to convert the encoding.

2.  **Braces:**  Check for mismatched or missing braces (`{` and `}`).  Every opening brace must have a corresponding closing brace.  Use an editor with brace matching to easily identify these errors.

3.  **Equals Signs:** Ensure properties are assigned using a single equals sign (`=`).  Incorrectly using `==` will cause errors. For instance, `chance = 0.001` is correct, while `chance == 0.001` is incorrect.

4.  **Keywords:** Verify that all keywords are spelled correctly.  Typos in keywords will prevent the game from recognizing the commands. For instance, `country_event` is correct, while `contry_event` is incorrect.

5.  **Comments:** Comments should start with a `#`. Make sure any commented-out code does not interfere with the active code structure.

6.  **Event Namespaces:** Every event should belong to a namespace. Check the namespace definitions and usage within the event files. For example, `namespace = ai_flavor_cleanup` in 'ai_flavor_cleanup.txt'.

7.  **Event IDs:** Event IDs must be unique within a namespace and follow the correct format (e.g., `ai_flavor_cleanup.1`). Ensure there are no duplicate IDs.

8.  **Missing semicolons**: Victoria 3 requires semicolons at the end of certain assignments in some specific files, such as those defining defines, but it is usually not required for events or ai strategies.

9.  **Incorrect use of 'id' or 'name':** Ensure that the correct tag is being used for each type of object. As Victoria 3 syntax can be similar to CK3, it can be easy to mix them up. Victoria 3 uses 'name' tag more often than CK3, which usually uses the 'id' tag. There is an example of a possible error in common/ai_strategies/disable_strategies.txt. Replace the 'id' tag with the 'name' tag. That would also require you to change the way that is ai strategy is referenced in the game files.

**Corrected example:**
```
ai_strategy = {
    name = "ai_strategy_join_alliances_everywhere"
    ai_weight = {
        weight = 0
    }
}
```

**II. Missing Localization Entries:**

Localization is the process of translating text in the game for different languages. Missing localization entries will cause the game to display the code name of the text instead of the translated text. In Victoria 3, localization files are typically YAML files.

1.  **File Location:** Localization files are located in the `Victoria 3 Performance/localization/<language>/` directory.  For English, the path would be `Victoria 3 Performance/localization/english/`.

2.  **File Format:** The files are YAML files (e.g., `mod_l_english.yml`). YAML files use a specific syntax. The basic structure is:

```yaml
l_<language>:
  <key>:0 "<localized text>"
  <another_key>:0 "<another localized text>"
```

    *   `l_<language>`: Specifies the language of the localization.
    *   `<key>`:  The unique identifier for the text (e.g., `mm_trade_overlay`). MUST match the name used in the code (e.g. inside events).
    *   `0`:  Indicates the version of the localization. Always use `0`.
    *   `"<localized text>"`: The translated text that will be displayed in the game.

3.  **Identifying Missing Entries:** Search the code for text strings that are displayed in the game, such as event titles, descriptions, decision names, etc. Check the corresponding localization files to see if these strings have entries.

4.  **Adding Missing Entries:** Add the missing entries to the appropriate YAML file, ensuring the correct syntax is used. The provided file `mod_map_modes_l_english.yml` is correctly formatted so can be used as an example.

5.  **Important Keys to Localize:**
    * decision names: locate names in `common/decisions/*`
    * journal entry names: locate names in `common/journal_entries/*`
    * ai strategy names: locate keys in `common/ai_strategies/*` (CK3).
    * map modes: check for 'tooltip' and 'name' entries in `common/map_modes/*`. Also check the gui files that call the names of map modes for a tooltip (example: `Victoria 3 Performance/gui/map_modes.gui`)

**Example of adding journal entries to a localisation file:**
First, you will have to locate which localisation file you will add the journal entries too. To keep things organised, create a new localisation file called `mod_journal_entries_l_english.yml`.

```yaml
l_english:
 je_expand_government:0 "Expand Government"
 je_promote_national_identity:0 "Promote National Identity"
 je_reform_military:0 "Reform Military"
 je_increase_standard_of_living:0 "Increase Standard of Living"
 je_industry_boost:0 "Industry Boost"
 je_expand_institution:0 "Expand Institution"
```

**III. Additional Notes & Corrections:**

1.  **Mod Metadata:** Check the `metadata.json` file. Although the example given is blank, this file should at least contain a unique `id` for the mod. Adding a version number is also good practice.
2.  **Victoria 3 vs. Crusader Kings 3:** It's *crucial* to understand that Victoria 3 and Crusader Kings 3, while sharing some similarities in scripting, are fundamentally different games. A mod designed for one will *not* work in the other without significant adaptation.
3.  **Clear Objectives:** Define precisely what aspects of the game you aim to optimize. This will help focus development and testing.
4.  **Granular Changes:** Make small, incremental changes and test them thoroughly. This makes it easier to identify the source of problems.
5.  **Compatibility:** Be aware of compatibility with other mods. Overlapping modifications can cause conflicts.
6.  **Commenting out triggers**: While the example event is not applicable to Crusader Kings 3, leaving the triggers of events blank is not sufficient to ensure the event never fires. Consider setting a very long mean_time_to_happen time to ensure the event never fires.
7.  **Error logs:** Check the error logs to understand what is causing problems with the mod.